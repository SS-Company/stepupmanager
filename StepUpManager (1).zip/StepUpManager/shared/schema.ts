// Schema for STEPS UP Investment Management System
// Integrates Replit Auth - see blueprint:javascript_log_in_with_replit
import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  serial,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (Required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table (Required for Replit Auth + role management)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { length: 20 }).notNull().default("investor"), // "admin" or "investor"
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Investors table (extends user with investment-specific fields)
export const investors = pgTable("investors", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().unique().references(() => users.id, { onDelete: 'cascade' }),
  investorId: varchar("investor_id", { length: 20 }).notNull().unique(),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  joinDate: timestamp("join_date").defaultNow().notNull(),
  status: varchar("status", { length: 20 }).default("active"),
  vipCode: varchar("vip_code", { length: 50 }).unique(),
  sponsorId: integer("sponsor_id"),
  totalInvested: decimal("total_invested", { precision: 15, scale: 2 }).default("0.00"),
  totalReturns: decimal("total_returns", { precision: 15, scale: 2 }).default("0.00"),
  totalCommissions: decimal("total_commissions", { precision: 15, scale: 2 }).default("0.00"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Investment Plans
export const investmentPlans = pgTable("investment_plans", {
  id: serial("id").primaryKey(),
  planName: varchar("plan_name", { length: 200 }).notNull(),
  minAmount: decimal("min_amount", { precision: 15, scale: 2 }).notNull(),
  maxAmount: decimal("max_amount", { precision: 15, scale: 2 }).notNull(),
  returnRate: decimal("return_rate", { precision: 5, scale: 2 }).notNull(),
  durationDays: integer("duration_days").notNull(),
  status: varchar("status", { length: 20 }).default("active"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Investments
export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  investorId: integer("investor_id").notNull().references(() => investors.id, { onDelete: 'cascade' }),
  planId: integer("plan_id").notNull().references(() => investmentPlans.id),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  expectedReturn: decimal("expected_return", { precision: 15, scale: 2 }).notNull(),
  actualReturn: decimal("actual_return", { precision: 15, scale: 2 }).default("0.00"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: varchar("status", { length: 20 }).default("active"), // active, completed, cancelled
  createdAt: timestamp("created_at").defaultNow(),
});

// VIP Codes
export const vipCodes = pgTable("vip_codes", {
  id: serial("id").primaryKey(),
  vipCode: varchar("vip_code", { length: 50 }).notNull().unique(),
  investorId: integer("investor_id").references(() => investors.id, { onDelete: 'set null' }),
  discountRate: decimal("discount_rate", { precision: 5, scale: 2 }).default("0.00"),
  maxUsage: integer("max_usage").default(1),
  usedCount: integer("used_count").default(0),
  status: varchar("status", { length: 20 }).default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Binary Tree Structure
export const binaryTree = pgTable("binary_tree", {
  id: serial("id").primaryKey(),
  investorId: integer("investor_id").notNull().unique().references(() => investors.id, { onDelete: 'cascade' }),
  parentId: integer("parent_id").references(() => investors.id),
  position: varchar("position", { length: 10 }), // "left" or "right"
  level: integer("level").default(0),
  leftCount: integer("left_count").default(0),
  rightCount: integer("right_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Commissions
export const commissions = pgTable("commissions", {
  id: serial("id").primaryKey(),
  investorId: integer("investor_id").notNull().references(() => investors.id, { onDelete: 'cascade' }),
  commissionType: varchar("commission_type", { length: 20 }).notNull(), // "binary", "vip", "referral"
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  fromInvestorId: integer("from_investor_id").references(() => investors.id, { onDelete: 'set null' }),
  fromInvestmentId: integer("from_investment_id").references(() => investments.id, { onDelete: 'set null' }),
  level: integer("level").default(0),
  description: text("description"),
  status: varchar("status", { length: 20 }).default("pending"), // pending, paid
  createdAt: timestamp("created_at").defaultNow(),
  paidAt: timestamp("paid_at"),
});

// Transactions
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  investorId: integer("investor_id").references(() => investors.id, { onDelete: 'set null' }),
  transactionType: varchar("transaction_type", { length: 20 }).notNull(), // "investment", "withdrawal", "commission", "bonus"
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  description: text("description"),
  reference: varchar("reference", { length: 100 }),
  status: varchar("status", { length: 20 }).default("completed"),
  transactionDate: timestamp("transaction_date").defaultNow(),
  createdBy: varchar("created_by"),
});

// Relations
export const usersRelations = relations(users, ({ one }) => ({
  investor: one(investors, {
    fields: [users.id],
    references: [investors.userId],
  }),
}));

export const investorsRelations = relations(investors, ({ one, many }) => ({
  user: one(users, {
    fields: [investors.userId],
    references: [users.id],
  }),
  sponsor: one(investors, {
    fields: [investors.sponsorId],
    references: [investors.id],
  }),
  investments: many(investments),
  commissions: many(commissions),
  binaryPosition: one(binaryTree),
}));

export const investmentPlansRelations = relations(investmentPlans, ({ many }) => ({
  investments: many(investments),
}));

export const investmentsRelations = relations(investments, ({ one }) => ({
  investor: one(investors, {
    fields: [investments.investorId],
    references: [investors.id],
  }),
  plan: one(investmentPlans, {
    fields: [investments.planId],
    references: [investmentPlans.id],
  }),
}));

export const commissionsRelations = relations(commissions, ({ one }) => ({
  investor: one(investors, {
    fields: [commissions.investorId],
    references: [investors.id],
  }),
  fromInvestor: one(investors, {
    fields: [commissions.fromInvestorId],
    references: [investors.id],
  }),
  fromInvestment: one(investments, {
    fields: [commissions.fromInvestmentId],
    references: [investments.id],
  }),
}));

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
  role: true,
});

export const insertInvestorSchema = createInsertSchema(investors).omit({
  id: true,
  createdAt: true,
});

export const insertInvestmentPlanSchema = createInsertSchema(investmentPlans).omit({
  id: true,
  createdAt: true,
});

export const insertInvestmentSchema = createInsertSchema(investments).omit({
  id: true,
  createdAt: true,
  actualReturn: true,
});

export const insertVipCodeSchema = createInsertSchema(vipCodes).omit({
  id: true,
  createdAt: true,
  usedCount: true,
});

export const insertCommissionSchema = createInsertSchema(commissions).omit({
  id: true,
  createdAt: true,
  paidAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  transactionDate: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertInvestor = z.infer<typeof insertInvestorSchema>;
export type Investor = typeof investors.$inferSelect;
export type InsertInvestmentPlan = z.infer<typeof insertInvestmentPlanSchema>;
export type InvestmentPlan = typeof investmentPlans.$inferSelect;
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;
export type Investment = typeof investments.$inferSelect;
export type InsertVipCode = z.infer<typeof insertVipCodeSchema>;
export type VipCode = typeof vipCodes.$inferSelect;
export type BinaryTreeNode = typeof binaryTree.$inferSelect;
export type InsertCommission = z.infer<typeof insertCommissionSchema>;
export type Commission = typeof commissions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
