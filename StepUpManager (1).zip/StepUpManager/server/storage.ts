// Database storage for STEPS UP Investment Management
// Based on blueprints: javascript_log_in_with_replit, javascript_database
import {
  users,
  investors,
  investmentPlans,
  investments,
  vipCodes,
  binaryTree,
  commissions,
  transactions,
  type User,
  type UpsertUser,
  type Investor,
  type InsertInvestor,
  type InvestmentPlan,
  type InsertInvestmentPlan,
  type Investment,
  type InsertInvestment,
  type VipCode,
  type InsertVipCode,
  type BinaryTreeNode,
  type Commission,
  type InsertCommission,
  type Transaction,
  type InsertTransaction,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (Required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Investor operations
  getInvestor(id: number): Promise<Investor | undefined>;
  getInvestorByUserId(userId: string): Promise<Investor | undefined>;
  getAllInvestors(): Promise<Investor[]>;
  createInvestor(investor: InsertInvestor): Promise<Investor>;
  updateInvestor(id: number, data: Partial<Investor>): Promise<Investor | undefined>;
  
  // Investment Plan operations
  getAllInvestmentPlans(): Promise<InvestmentPlan[]>;
  getInvestmentPlan(id: number): Promise<InvestmentPlan | undefined>;
  createInvestmentPlan(plan: InsertInvestmentPlan): Promise<InvestmentPlan>;
  updateInvestmentPlan(id: number, data: Partial<InvestmentPlan>): Promise<InvestmentPlan | undefined>;
  
  // Investment operations
  getAllInvestments(): Promise<Investment[]>;
  getInvestment(id: number): Promise<Investment | undefined>;
  getInvestmentsByInvestor(investorId: number): Promise<Investment[]>;
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  updateInvestment(id: number, data: Partial<Investment>): Promise<Investment | undefined>;
  
  // VIP Code operations
  getAllVipCodes(): Promise<VipCode[]>;
  getVipCode(code: string): Promise<VipCode | undefined>;
  createVipCode(vipCode: InsertVipCode): Promise<VipCode>;
  updateVipCode(id: number, data: Partial<VipCode>): Promise<VipCode | undefined>;
  
  // Binary Tree operations
  getBinaryTreeNode(investorId: number): Promise<BinaryTreeNode | undefined>;
  createBinaryTreeNode(investorId: number, parentId: number | null, position: string): Promise<BinaryTreeNode>;
  updateBinaryTreeCounts(investorId: number, leftCount: number, rightCount: number): Promise<void>;
  
  // Commission operations
  getAllCommissions(): Promise<Commission[]>;
  getCommissionsByInvestor(investorId: number): Promise<Commission[]>;
  createCommission(commission: InsertCommission): Promise<Commission>;
  updateCommissionStatus(id: number, status: string, paidAt?: Date): Promise<Commission | undefined>;
  
  // Transaction operations
  getAllTransactions(): Promise<Transaction[]>;
  getTransactionsByInvestor(investorId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
}

export class DatabaseStorage implements IStorage {
  // User operations (Required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Investor operations
  async getInvestor(id: number): Promise<Investor | undefined> {
    const [investor] = await db.select().from(investors).where(eq(investors.id, id));
    return investor;
  }

  async getInvestorByUserId(userId: string): Promise<Investor | undefined> {
    const [investor] = await db.select().from(investors).where(eq(investors.userId, userId));
    return investor;
  }

  async getAllInvestors(): Promise<Investor[]> {
    return await db.select().from(investors).orderBy(desc(investors.createdAt));
  }

  async createInvestor(investorData: InsertInvestor): Promise<Investor> {
    const [investor] = await db.insert(investors).values(investorData).returning();
    return investor;
  }

  async updateInvestor(id: number, data: Partial<Investor>): Promise<Investor | undefined> {
    const [investor] = await db
      .update(investors)
      .set(data)
      .where(eq(investors.id, id))
      .returning();
    return investor;
  }

  // Investment Plan operations
  async getAllInvestmentPlans(): Promise<InvestmentPlan[]> {
    return await db.select().from(investmentPlans).where(eq(investmentPlans.status, "active"));
  }

  async getInvestmentPlan(id: number): Promise<InvestmentPlan | undefined> {
    const [plan] = await db.select().from(investmentPlans).where(eq(investmentPlans.id, id));
    return plan;
  }

  async createInvestmentPlan(planData: InsertInvestmentPlan): Promise<InvestmentPlan> {
    const [plan] = await db.insert(investmentPlans).values(planData).returning();
    return plan;
  }

  async updateInvestmentPlan(id: number, data: Partial<InvestmentPlan>): Promise<InvestmentPlan | undefined> {
    const [plan] = await db
      .update(investmentPlans)
      .set(data)
      .where(eq(investmentPlans.id, id))
      .returning();
    return plan;
  }

  // Investment operations
  async getAllInvestments(): Promise<Investment[]> {
    return await db.select().from(investments).orderBy(desc(investments.createdAt));
  }

  async getInvestment(id: number): Promise<Investment | undefined> {
    const [investment] = await db.select().from(investments).where(eq(investments.id, id));
    return investment;
  }

  async getInvestmentsByInvestor(investorId: number): Promise<Investment[]> {
    return await db.select().from(investments).where(eq(investments.investorId, investorId));
  }

  async createInvestment(investmentData: InsertInvestment): Promise<Investment> {
    const [investment] = await db.insert(investments).values(investmentData).returning();
    return investment;
  }

  async updateInvestment(id: number, data: Partial<Investment>): Promise<Investment | undefined> {
    const [investment] = await db
      .update(investments)
      .set(data)
      .where(eq(investments.id, id))
      .returning();
    return investment;
  }

  // VIP Code operations
  async getAllVipCodes(): Promise<VipCode[]> {
    return await db.select().from(vipCodes).orderBy(desc(vipCodes.createdAt));
  }

  async getVipCode(code: string): Promise<VipCode | undefined> {
    const [vipCode] = await db.select().from(vipCodes).where(eq(vipCodes.vipCode, code));
    return vipCode;
  }

  async createVipCode(vipCodeData: InsertVipCode): Promise<VipCode> {
    const [vipCode] = await db.insert(vipCodes).values(vipCodeData).returning();
    return vipCode;
  }

  async updateVipCode(id: number, data: Partial<VipCode>): Promise<VipCode | undefined> {
    const [vipCode] = await db
      .update(vipCodes)
      .set(data)
      .where(eq(vipCodes.id, id))
      .returning();
    return vipCode;
  }

  // Binary Tree operations
  async getBinaryTreeNode(investorId: number): Promise<BinaryTreeNode | undefined> {
    const [node] = await db.select().from(binaryTree).where(eq(binaryTree.investorId, investorId));
    return node;
  }

  async createBinaryTreeNode(investorId: number, parentId: number | null, position: string): Promise<BinaryTreeNode> {
    const [node] = await db.insert(binaryTree).values({
      investorId,
      parentId,
      position,
      level: 0,
      leftCount: 0,
      rightCount: 0,
    }).returning();
    return node;
  }

  async updateBinaryTreeCounts(investorId: number, leftCount: number, rightCount: number): Promise<void> {
    await db
      .update(binaryTree)
      .set({ leftCount, rightCount })
      .where(eq(binaryTree.investorId, investorId));
  }

  // Commission operations
  async getAllCommissions(): Promise<Commission[]> {
    return await db.select().from(commissions).orderBy(desc(commissions.createdAt));
  }

  async getCommissionsByInvestor(investorId: number): Promise<Commission[]> {
    return await db.select().from(commissions).where(eq(commissions.investorId, investorId));
  }

  async createCommission(commissionData: InsertCommission): Promise<Commission> {
    const [commission] = await db.insert(commissions).values(commissionData).returning();
    return commission;
  }

  async updateCommissionStatus(id: number, status: string, paidAt?: Date): Promise<Commission | undefined> {
    const [commission] = await db
      .update(commissions)
      .set({ status, paidAt })
      .where(eq(commissions.id, id))
      .returning();
    return commission;
  }

  // Transaction operations
  async getAllTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions).orderBy(desc(transactions.transactionDate));
  }

  async getTransactionsByInvestor(investorId: number): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.investorId, investorId));
  }

  async createTransaction(transactionData: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values(transactionData).returning();
    return transaction;
  }
}

export const storage = new DatabaseStorage();
