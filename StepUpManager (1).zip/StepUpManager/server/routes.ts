// API Routes for STEPS UP Investment Management
// Based on blueprint:javascript_log_in_with_replit
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";
import {
  insertInvestorSchema,
  insertInvestmentPlanSchema,
  insertInvestmentSchema,
  insertVipCodeSchema,
  insertCommissionSchema,
  insertTransactionSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // ====================
  // Investor Routes
  // ====================
  
  // Get all investors (admin only)
  app.get("/api/investors", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const allInvestors = await storage.getAllInvestors();
      res.json(allInvestors);
    } catch (error) {
      console.error("Error fetching investors:", error);
      res.status(500).json({ message: "Failed to fetch investors" });
    }
  });

  // Get current investor profile
  app.get("/api/investor/profile", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investor = await storage.getInvestorByUserId(userId);
      res.json(investor);
    } catch (error) {
      console.error("Error fetching investor profile:", error);
      res.status(500).json({ message: "Failed to fetch investor profile" });
    }
  });

  // Create investor profile
  app.post("/api/investors", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertInvestorSchema.parse(req.body);
      const investor = await storage.createInvestor(validatedData);
      res.status(201).json(investor);
    } catch (error: any) {
      console.error("Error creating investor:", error);
      res.status(400).json({ message: error.message || "Failed to create investor" });
    }
  });

  // Update investor
  app.patch("/api/investors/:id", isAuthenticated, async (req: any, res) => {
    try {
      const id = parseInt(req.params.id);
      const investor = await storage.updateInvestor(id, req.body);
      if (!investor) {
        return res.status(404).json({ message: "Investor not found" });
      }
      res.json(investor);
    } catch (error) {
      console.error("Error updating investor:", error);
      res.status(500).json({ message: "Failed to update investor" });
    }
  });

  // Promote user to admin (admin only - for initial setup, first user can self-promote)
  app.post("/api/admin/promote-admin", isAuthenticated, async (req: any, res) => {
    try {
      // Validate request body
      const schema = z.object({
        userId: z.string().min(1, "User ID is required"),
      });
      
      const validatedData = schema.parse(req.body);
      
      const currentUser = await storage.getUser(req.user.claims.sub);
      const allUsers = await db.select().from(users);
      
      // Allow first user to self-promote, or require existing admin
      const isFirstUser = allUsers.length === 1 && allUsers[0].id === currentUser?.id;
      const isAdmin = currentUser?.role === "admin";
      
      if (!isFirstUser && !isAdmin) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const targetUser = await storage.getUser(validatedData.userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await db.update(users).set({ role: "admin" }).where(eq(users.id, validatedData.userId));
      const updatedUser = await storage.getUser(validatedData.userId);
      
      res.json(updatedUser);
    } catch (error: any) {
      console.error("Error promoting admin:", error);
      if (error.name === "ZodError") {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to promote admin" });
    }
  });

  // ====================
  // Investment Plan Routes
  // ====================
  
  // Get all investment plans
  app.get("/api/investment-plans", isAuthenticated, async (req, res) => {
    try {
      const plans = await storage.getAllInvestmentPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching investment plans:", error);
      res.status(500).json({ message: "Failed to fetch investment plans" });
    }
  });

  // Create investment plan (admin only)
  app.post("/api/investment-plans", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const validatedData = insertInvestmentPlanSchema.parse(req.body);
      const plan = await storage.createInvestmentPlan(validatedData);
      res.status(201).json(plan);
    } catch (error: any) {
      console.error("Error creating investment plan:", error);
      res.status(400).json({ message: error.message || "Failed to create investment plan" });
    }
  });

  // Update investment plan (admin only)
  app.patch("/api/investment-plans/:id", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const id = parseInt(req.params.id);
      const plan = await storage.updateInvestmentPlan(id, req.body);
      if (!plan) {
        return res.status(404).json({ message: "Investment plan not found" });
      }
      res.json(plan);
    } catch (error) {
      console.error("Error updating investment plan:", error);
      res.status(500).json({ message: "Failed to update investment plan" });
    }
  });

  // ====================
  // Investment Routes
  // ====================
  
  // Get all investments (admin only)
  app.get("/api/investments", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const allInvestments = await storage.getAllInvestments();
      res.json(allInvestments);
    } catch (error) {
      console.error("Error fetching investments:", error);
      res.status(500).json({ message: "Failed to fetch investments" });
    }
  });

  // Get investor's investments
  app.get("/api/investor/investments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investor = await storage.getInvestorByUserId(userId);
      if (!investor) {
        return res.status(404).json({ message: "Investor profile not found" });
      }
      
      const investments = await storage.getInvestmentsByInvestor(investor.id);
      res.json(investments);
    } catch (error) {
      console.error("Error fetching investor investments:", error);
      res.status(500).json({ message: "Failed to fetch investments" });
    }
  });

  // Create investment
  app.post("/api/investments", isAuthenticated, async (req: any, res) => {
    try {
      const validatedData = insertInvestmentSchema.parse(req.body);
      const investment = await storage.createInvestment(validatedData);
      
      // Create transaction record
      await storage.createTransaction({
        investorId: validatedData.investorId,
        transactionType: "investment",
        amount: validatedData.amount.toString(),
        description: `Investment in plan ${validatedData.planId}`,
        status: "completed",
      });
      
      res.status(201).json(investment);
    } catch (error: any) {
      console.error("Error creating investment:", error);
      res.status(400).json({ message: error.message || "Failed to create investment" });
    }
  });

  // ====================
  // VIP Code Routes
  // ====================
  
  // Get all VIP codes (admin only)
  app.get("/api/vip-codes", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const vipCodes = await storage.getAllVipCodes();
      res.json(vipCodes);
    } catch (error) {
      console.error("Error fetching VIP codes:", error);
      res.status(500).json({ message: "Failed to fetch VIP codes" });
    }
  });

  // Generate VIP code (admin only)
  app.post("/api/vip-codes", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Generate unique VIP code
      const codePrefix = "VIP";
      const randomStr = Math.random().toString(36).substring(2, 8).toUpperCase();
      const vipCodeStr = `${codePrefix}-${randomStr}`;
      
      const validatedData = insertVipCodeSchema.parse({
        ...req.body,
        vipCode: vipCodeStr,
      });
      
      const vipCode = await storage.createVipCode(validatedData);
      res.status(201).json(vipCode);
    } catch (error: any) {
      console.error("Error creating VIP code:", error);
      res.status(400).json({ message: error.message || "Failed to create VIP code" });
    }
  });

  // Validate VIP code
  app.get("/api/vip-codes/validate/:code", isAuthenticated, async (req, res) => {
    try {
      const vipCode = await storage.getVipCode(req.params.code);
      if (!vipCode) {
        return res.status(404).json({ message: "VIP code not found" });
      }
      
      const isValid = vipCode.status === "active" && vipCode.usedCount < vipCode.maxUsage;
      res.json({ valid: isValid, code: vipCode });
    } catch (error) {
      console.error("Error validating VIP code:", error);
      res.status(500).json({ message: "Failed to validate VIP code" });
    }
  });

  // ====================
  // Binary Network Routes
  // ====================
  
  // Get binary tree node for investor
  app.get("/api/binary-tree/:investorId", isAuthenticated, async (req, res) => {
    try {
      const investorId = parseInt(req.params.investorId);
      const node = await storage.getBinaryTreeNode(investorId);
      res.json(node);
    } catch (error) {
      console.error("Error fetching binary tree node:", error);
      res.status(500).json({ message: "Failed to fetch binary tree node" });
    }
  });

  // Get current investor's binary position
  app.get("/api/investor/binary-position", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investor = await storage.getInvestorByUserId(userId);
      if (!investor) {
        return res.status(404).json({ message: "Investor profile not found" });
      }
      
      const node = await storage.getBinaryTreeNode(investor.id);
      res.json(node);
    } catch (error) {
      console.error("Error fetching binary position:", error);
      res.status(500).json({ message: "Failed to fetch binary position" });
    }
  });

  // ====================
  // Commission Routes
  // ====================
  
  // Get all commissions (admin only)
  app.get("/api/commissions", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const commissions = await storage.getAllCommissions();
      res.json(commissions);
    } catch (error) {
      console.error("Error fetching commissions:", error);
      res.status(500).json({ message: "Failed to fetch commissions" });
    }
  });

  // Get investor's commissions
  app.get("/api/investor/commissions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investor = await storage.getInvestorByUserId(userId);
      if (!investor) {
        return res.status(404).json({ message: "Investor profile not found" });
      }
      
      const commissions = await storage.getCommissionsByInvestor(investor.id);
      res.json(commissions);
    } catch (error) {
      console.error("Error fetching investor commissions:", error);
      res.status(500).json({ message: "Failed to fetch commissions" });
    }
  });

  // Create commission (admin only - for manual commission entry)
  app.post("/api/commissions", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const validatedData = insertCommissionSchema.parse(req.body);
      const commission = await storage.createCommission(validatedData);
      res.status(201).json(commission);
    } catch (error: any) {
      console.error("Error creating commission:", error);
      res.status(400).json({ message: error.message || "Failed to create commission" });
    }
  });

  // Update commission status (admin only)
  app.patch("/api/commissions/:id/status", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const paidAt = status === "paid" ? new Date() : undefined;
      
      const commission = await storage.updateCommissionStatus(id, status, paidAt);
      if (!commission) {
        return res.status(404).json({ message: "Commission not found" });
      }
      
      res.json(commission);
    } catch (error) {
      console.error("Error updating commission status:", error);
      res.status(500).json({ message: "Failed to update commission status" });
    }
  });

  // ====================
  // Transaction Routes
  // ====================
  
  // Get all transactions (admin only)
  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Get investor's transactions
  app.get("/api/investor/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investor = await storage.getInvestorByUserId(userId);
      if (!investor) {
        return res.status(404).json({ message: "Investor profile not found" });
      }
      
      const transactions = await storage.getTransactionsByInvestor(investor.id);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching investor transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // ====================
  // Statistics/Reports Routes
  // ====================
  
  // Get dashboard statistics (admin only)
  app.get("/api/stats/dashboard", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const investors = await storage.getAllInvestors();
      const investments = await storage.getAllInvestments();
      const commissions = await storage.getAllCommissions();
      const vipCodes = await storage.getAllVipCodes();
      
      const totalInvested = investments.reduce((sum, inv) => 
        sum + parseFloat(inv.amount.toString()), 0
      );
      
      const totalCommissions = commissions
        .filter(c => c.status === "paid")
        .reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0);
      
      const activeVipCodes = vipCodes.filter(v => v.status === "active").length;
      
      res.json({
        totalInvestors: investors.length,
        activeInvestments: investments.filter(i => i.status === "active").length,
        totalInvested,
        totalCommissionsPaid: totalCommissions,
        activeVipCodes,
      });
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard statistics" });
    }
  });

  // Get investor dashboard statistics
  app.get("/api/investor/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investor = await storage.getInvestorByUserId(userId);
      if (!investor) {
        return res.status(404).json({ message: "Investor profile not found" });
      }
      
      const investments = await storage.getInvestmentsByInvestor(investor.id);
      const commissions = await storage.getCommissionsByInvestor(investor.id);
      const binaryNode = await storage.getBinaryTreeNode(investor.id);
      
      const totalInvested = investments.reduce((sum, inv) => 
        sum + parseFloat(inv.amount.toString()), 0
      );
      
      const expectedReturns = investments
        .filter(i => i.status === "active")
        .reduce((sum, inv) => sum + parseFloat(inv.expectedReturn.toString()), 0);
      
      const totalCommissions = commissions
        .filter(c => c.status === "paid")
        .reduce((sum, c) => sum + parseFloat(c.amount.toString()), 0);
      
      const networkSize = (binaryNode?.leftCount || 0) + (binaryNode?.rightCount || 0);
      
      res.json({
        totalInvested,
        expectedReturns,
        totalCommissions,
        networkSize,
        leftLeg: binaryNode?.leftCount || 0,
        rightLeg: binaryNode?.rightCount || 0,
      });
    } catch (error) {
      console.error("Error fetching investor stats:", error);
      res.status(500).json({ message: "Failed to fetch investor statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
