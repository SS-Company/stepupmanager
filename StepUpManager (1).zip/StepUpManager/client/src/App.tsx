// STEPS UP Investment Management System
// Integrates Replit Auth - see blueprint:javascript_log_in_with_replit
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { InvestorNav } from "@/components/investor-nav";
import { useAuth } from "@/hooks/useAuth";
import { TrendingUp, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

// Pages
import Landing from "@/pages/landing";
import NotFound from "@/pages/not-found";

// Admin Pages
import AdminDashboard from "@/pages/admin/dashboard";
import InvestorsPage from "@/pages/admin/investors";
import InvestmentsPage from "@/pages/admin/investments";
import VIPCodesPage from "@/pages/admin/vip-codes";
import BinaryNetworkPage from "@/pages/admin/binary-network";
import CommissionsPage from "@/pages/admin/commissions";
import ReportsPage from "@/pages/admin/reports";
import SettingsPage from "@/pages/admin/settings";

// Investor Pages
import InvestorDashboard from "@/pages/investor/dashboard";
import InvestorInvestments from "@/pages/investor/investments";
import InvestorCommissions from "@/pages/investor/commissions";
import InvestorNetwork from "@/pages/investor/network";

function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  
  return (
    <div className="flex h-screen w-full">
      <AppSidebar />
      <div className="flex flex-col flex-1">
        <header className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <div className="flex items-center gap-2 pl-2 border-l">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImageUrl || ""} />
                <AvatarFallback>
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              <div className="hidden md:block">
                <p className="text-sm font-medium">
                  {user?.firstName} {user?.lastName}
                </p>
                <p className="text-xs text-muted-foreground">Administrator</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => window.location.href = "/api/logout"}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

function InvestorLayout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary">
                  <TrendingUp className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-lg font-heading font-bold">STEPS UP</h1>
                  <p className="text-xs text-muted-foreground">Investment Manager</p>
                </div>
              </div>
              <div className="hidden lg:block">
                <InvestorNav />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <div className="flex items-center gap-2 pl-2 border-l">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user?.profileImageUrl || ""} />
                  <AvatarFallback>
                    {user?.firstName?.[0]}{user?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden md:block">
                  <p className="text-sm font-medium">
                    {user?.firstName} {user?.lastName}
                  </p>
                  <p className="text-xs text-muted-foreground">Investor</p>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:hidden mt-4">
            <InvestorNav />
          </div>
        </div>
      </header>
      <main className="flex-1 container mx-auto px-6 py-8">
        {children}
      </main>
      <footer className="border-t mt-auto">
        <div className="container mx-auto px-6 py-6">
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} STEPS UP Trade Pvt. Ltd. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

function Router() {
  const { isAuthenticated, isLoading, isAdmin } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary mb-4 animate-pulse">
            <TrendingUp className="h-8 w-8" />
          </div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Landing />;
  }

  if (isAdmin) {
    return (
      <Switch>
        <Route path="/admin" component={() => <AdminLayout><AdminDashboard /></AdminLayout>} />
        <Route path="/admin/investors" component={() => <AdminLayout><InvestorsPage /></AdminLayout>} />
        <Route path="/admin/investments" component={() => <AdminLayout><InvestmentsPage /></AdminLayout>} />
        <Route path="/admin/vip-codes" component={() => <AdminLayout><VIPCodesPage /></AdminLayout>} />
        <Route path="/admin/binary-network" component={() => <AdminLayout><BinaryNetworkPage /></AdminLayout>} />
        <Route path="/admin/commissions" component={() => <AdminLayout><CommissionsPage /></AdminLayout>} />
        <Route path="/admin/reports" component={() => <AdminLayout><ReportsPage /></AdminLayout>} />
        <Route path="/admin/settings" component={() => <AdminLayout><SettingsPage /></AdminLayout>} />
        <Route path="/" component={() => <AdminLayout><AdminDashboard /></AdminLayout>} />
        <Route component={NotFound} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={() => <InvestorLayout><InvestorDashboard /></InvestorLayout>} />
      <Route path="/investments" component={() => <InvestorLayout><InvestorInvestments /></InvestorLayout>} />
      <Route path="/commissions" component={() => <InvestorLayout><InvestorCommissions /></InvestorLayout>} />
      <Route path="/network" component={() => <InvestorLayout><InvestorNetwork /></InvestorLayout>} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={sidebarStyle as React.CSSProperties}>
          <Toaster />
          <Router />
        </SidebarProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
