import { Button } from "@/components/ui/button";
import { LayoutDashboard, TrendingUp, DollarSign, Users, LogOut } from "lucide-react";
import { useLocation } from "wouter";

const investorMenuItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "My Investments",
    url: "/investments",
    icon: TrendingUp,
  },
  {
    title: "Commissions",
    url: "/commissions",
    icon: DollarSign,
  },
  {
    title: "My Network",
    url: "/network",
    icon: Users,
  },
];

export function InvestorNav() {
  const [location] = useLocation();

  return (
    <nav className="flex items-center gap-1">
      {investorMenuItems.map((item) => {
        const Icon = item.icon;
        const isActive = location === item.url;
        return (
          <Button
            key={item.url}
            variant={isActive ? "default" : "ghost"}
            size="sm"
            asChild
            data-testid={`link-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <a href={item.url} className="flex items-center gap-2">
              <Icon className="h-4 w-4" />
              <span className="hidden md:inline">{item.title}</span>
            </a>
          </Button>
        );
      })}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => window.location.href = "/api/logout"}
        data-testid="button-logout"
        className="ml-2"
      >
        <LogOut className="h-4 w-4" />
        <span className="hidden md:inline ml-2">Logout</span>
      </Button>
    </nav>
  );
}
