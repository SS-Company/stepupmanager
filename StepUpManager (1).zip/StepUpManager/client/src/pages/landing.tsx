// Landing page for logged-out users
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Users, DollarSign, Award, ChevronRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-accent/20">
      <header className="border-b bg-background/95 backdrop-blur">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary">
                <TrendingUp className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-lg font-heading font-bold">STEPS UP</h1>
                <p className="text-xs text-muted-foreground">Investment Management</p>
              </div>
            </div>
            <Button
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-login"
            >
              Sign In
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="container mx-auto px-6 py-24">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-4xl font-heading font-bold tracking-tight sm:text-5xl lg:text-6xl">
              Professional Investment
              <span className="text-primary"> Management Platform</span>
            </h2>
            <p className="mt-6 text-lg text-muted-foreground">
              STEPS UP Trade Pvt. Ltd. brings you a comprehensive investment management system
              with multi-layer binary network, VIP rewards, and automated commission tracking.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-get-started"
              >
                Get Started
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-investor-portal"
              >
                Investor Portal
              </Button>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-6 py-16">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            <Card className="border-2">
              <CardContent className="p-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary/10 text-primary">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <h3 className="mt-4 font-heading font-semibold text-lg">Smart Investments</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Multiple investment plans with competitive returns tailored to your goals.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary/10 text-primary">
                  <Users className="h-6 w-6" />
                </div>
                <h3 className="mt-4 font-heading font-semibold text-lg">Binary Network</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Build your network with our proven binary tree structure for passive income.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary/10 text-primary">
                  <DollarSign className="h-6 w-6" />
                </div>
                <h3 className="mt-4 font-heading font-semibold text-lg">Commission Tracking</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Transparent commission system with real-time tracking and automated payouts.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardContent className="p-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary/10 text-primary">
                  <Award className="h-6 w-6" />
                </div>
                <h3 className="mt-4 font-heading font-semibold text-lg">VIP Rewards</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Exclusive VIP codes and special rewards for top-performing investors.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="container mx-auto px-6 py-16">
          <Card className="border-2 bg-primary text-primary-foreground">
            <CardContent className="p-12 text-center">
              <h3 className="text-2xl font-heading font-bold">Ready to Start Investing?</h3>
              <p className="mt-4 text-primary-foreground/90">
                Join thousands of investors building wealth with STEPS UP Trade Pvt. Ltd.
              </p>
              <Button
                size="lg"
                variant="secondary"
                className="mt-8"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-join-now"
              >
                Join Now
              </Button>
            </CardContent>
          </Card>
        </section>
      </main>

      <footer className="border-t mt-16">
        <div className="container mx-auto px-6 py-8">
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} STEPS UP Trade Pvt. Ltd. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
