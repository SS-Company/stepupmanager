import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-heading font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage system configuration and preferences</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Company Information</CardTitle>
          <CardDescription>Update your company details and branding</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="company-name">Company Name</Label>
              <Input
                id="company-name"
                defaultValue="STEPS UP Trade Pvt. Ltd."
                data-testid="input-company-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="active-date">Active Since</Label>
              <Input
                id="active-date"
                type="date"
                defaultValue="2020-04-14"
                data-testid="input-active-date"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="header-text">Header Text</Label>
            <Input
              id="header-text"
              defaultValue="STEPS UP Investment Management System"
              data-testid="input-header-text"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="footer-text">Footer Text</Label>
            <Input
              id="footer-text"
              defaultValue="© 2024 STEPS UP Trade Pvt. Ltd. All rights reserved."
              data-testid="input-footer-text"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Commission Rates</CardTitle>
          <CardDescription>Configure commission percentages for different types</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="binary-rate">Binary Commission (%)</Label>
              <Input
                id="binary-rate"
                type="number"
                defaultValue="10"
                min="0"
                max="100"
                step="0.1"
                data-testid="input-binary-rate"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vip-rate">VIP Commission (%)</Label>
              <Input
                id="vip-rate"
                type="number"
                defaultValue="15"
                min="0"
                max="100"
                step="0.1"
                data-testid="input-vip-rate"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="referral-rate">Referral Commission (%)</Label>
              <Input
                id="referral-rate"
                type="number"
                defaultValue="5"
                min="0"
                max="100"
                step="0.1"
                data-testid="input-referral-rate"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">System Preferences</CardTitle>
          <CardDescription>General system settings and configurations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="currency">Default Currency</Label>
            <Input
              id="currency"
              defaultValue="USD"
              data-testid="input-currency"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="timezone">Timezone</Label>
            <Input
              id="timezone"
              defaultValue="UTC"
              data-testid="input-timezone"
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Cancel</Button>
        <Button data-testid="button-save-settings">Save Changes</Button>
      </div>
    </div>
  );
}
