import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function BinaryNetworkPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-heading font-bold tracking-tight">Binary Network</h1>
        <p className="text-muted-foreground">Visualize and manage the binary tree structure</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-heading">Network Tree</CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon">
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <ZoomIn className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[600px] flex items-center justify-center border-2 border-dashed rounded-md">
              <div className="text-center space-y-4">
                <div className="flex flex-col items-center gap-4">
                  <div className="relative">
                    <Avatar className="h-16 w-16 border-2 border-primary">
                      <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
                        RT
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs font-medium whitespace-nowrap">
                      Root
                    </div>
                  </div>
                  <div className="flex gap-12 mt-12">
                    <div className="flex flex-col items-center gap-2">
                      <Avatar className="h-12 w-12 border-2">
                        <AvatarFallback>L1</AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">Left</span>
                    </div>
                    <div className="flex flex-col items-center gap-2">
                      <Avatar className="h-12 w-12 border-2">
                        <AvatarFallback>R1</AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">Right</span>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-8">
                  Interactive tree visualization - will connect to real data
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Search Investor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by name or ID..."
                className="pl-9"
                data-testid="input-search-network"
              />
            </div>

            <div className="space-y-4 pt-4">
              <div>
                <h4 className="text-sm font-semibold mb-2">Network Stats</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Network Size</span>
                    <span className="font-semibold">1,234</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Left Leg Count</span>
                    <span className="font-semibold">567</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Right Leg Count</span>
                    <span className="font-semibold">667</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Max Depth</span>
                    <span className="font-semibold">12 levels</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
