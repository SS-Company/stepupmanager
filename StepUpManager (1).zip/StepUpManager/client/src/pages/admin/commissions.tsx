import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { StatCard } from "@/components/stat-card";
import { DollarSign } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function CommissionsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-heading font-bold tracking-tight">Commissions</h1>
        <p className="text-muted-foreground">Track and manage all commission payouts</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard
          title="Total Commissions Paid"
          value="$125,000"
          icon={DollarSign}
          description="All time"
        />
        <StatCard
          title="Pending Payouts"
          value="$12,500"
          icon={DollarSign}
          description="Awaiting approval"
        />
        <StatCard
          title="This Month"
          value="$25,000"
          icon={DollarSign}
          trend={{ value: 15, isPositive: true }}
          description="vs last month"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-base">Binary Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-heading">$75,000</div>
            <p className="text-xs text-muted-foreground mt-1">60% of total</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-base">VIP Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-heading">$37,500</div>
            <p className="text-xs text-muted-foreground mt-1">30% of total</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-base">Referral Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-heading">$12,500</div>
            <p className="text-xs text-muted-foreground mt-1">10% of total</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4">
            <CardTitle className="font-heading">All Commissions</CardTitle>
            <div className="flex items-center gap-2">
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px]" data-testid="select-commission-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="binary">Binary</SelectItem>
                  <SelectItem value="vip">VIP</SelectItem>
                  <SelectItem value="referral">Referral</SelectItem>
                </SelectContent>
              </Select>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search..."
                  className="pl-9 w-[200px]"
                  data-testid="input-search-commissions"
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Investor</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>From</TableHead>
                <TableHead>Level</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">John Doe</TableCell>
                <TableCell>
                  <Badge variant="outline">Binary</Badge>
                </TableCell>
                <TableCell className="font-semibold">$2,500</TableCell>
                <TableCell>Jane Smith</TableCell>
                <TableCell>Level 2</TableCell>
                <TableCell>Jan 15, 2024</TableCell>
                <TableCell>
                  <Badge variant="default">Paid</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" data-testid="button-view-commission">
                    View
                  </Button>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Alice Johnson</TableCell>
                <TableCell>
                  <Badge variant="outline">VIP</Badge>
                </TableCell>
                <TableCell className="font-semibold">$1,250</TableCell>
                <TableCell>Bob Williams</TableCell>
                <TableCell>-</TableCell>
                <TableCell>Jan 16, 2024</TableCell>
                <TableCell>
                  <Badge variant="secondary">Pending</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" data-testid="button-approve-commission">
                    Approve
                  </Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
