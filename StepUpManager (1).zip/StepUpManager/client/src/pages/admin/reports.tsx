import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Calendar } from "lucide-react";
import { StatCard } from "@/components/stat-card";
import { TrendingUp, Users, DollarSign, Award } from "lucide-react";

export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">Analytics and performance insights</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Date Range
          </Button>
          <Button data-testid="button-export-report">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <StatCard
          title="Total Revenue"
          value="$2.5M"
          icon={DollarSign}
          trend={{ value: 12, isPositive: true }}
          description="vs last period"
        />
        <StatCard
          title="New Investors"
          value="234"
          icon={Users}
          trend={{ value: 8, isPositive: true }}
          description="this month"
        />
        <StatCard
          title="Active Investments"
          value="1,456"
          icon={TrendingUp}
          trend={{ value: 5, isPositive: true }}
          description="vs last month"
        />
        <StatCard
          title="VIP Members"
          value="89"
          icon={Award}
          trend={{ value: 15, isPositive: true }}
          description="growing"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Investment Growth Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center text-muted-foreground border-2 border-dashed rounded-md">
              Line chart placeholder
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Commission Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center text-muted-foreground border-2 border-dashed rounded-md">
              Pie chart placeholder
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Top Performers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold text-sm">
                      {i}
                    </div>
                    <div>
                      <div className="font-medium">Investor {i}</div>
                      <div className="text-sm text-muted-foreground">Level {i}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">${(100000 - i * 10000).toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">Total invested</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Monthly Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">New Investments</span>
                <span className="font-semibold text-lg">89</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">Matured Investments</span>
                <span className="font-semibold text-lg">45</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">Commissions Paid</span>
                <span className="font-semibold text-lg">$25,000</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">VIP Codes Generated</span>
                <span className="font-semibold text-lg">12</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
