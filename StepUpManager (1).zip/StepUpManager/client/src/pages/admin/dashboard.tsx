import { StatCard } from "@/components/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, TrendingUp, DollarSign, Tag } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";

export default function AdminDashboard() {
  const { data: stats, isLoading } = useQuery<any>({
    queryKey: ["/api/stats/dashboard"],
  });

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div>
          <Skeleton className="h-9 w-48 mb-2" />
          <Skeleton className="h-5 w-72" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-heading font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your investment platform</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Investors"
          value={stats?.totalInvestors?.toString() || "0"}
          icon={Users}
          description="registered users"
        />
        <StatCard
          title="Active Investments"
          value={stats?.activeInvestments?.toString() || "0"}
          icon={TrendingUp}
          description="ongoing plans"
        />
        <StatCard
          title="Total Invested"
          value={`$${stats?.totalInvested?.toLocaleString() || "0"}`}
          icon={DollarSign}
          description="capital deployed"
        />
        <StatCard
          title="Commissions Paid"
          value={`$${stats?.totalCommissionsPaid?.toLocaleString() || "0"}`}
          icon={DollarSign}
          description="total payouts"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Investment Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center text-muted-foreground border-2 border-dashed rounded-md">
              Chart visualization - coming soon
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Platform Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">Active VIP Codes</span>
                <span className="font-semibold text-lg">{stats?.activeVipCodes || 0}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">Total Investors</span>
                <span className="font-semibold text-lg">{stats?.totalInvestors || 0}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">Active Investments</span>
                <span className="font-semibold text-lg">{stats?.activeInvestments || 0}</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md bg-muted/50">
                <span className="text-sm text-muted-foreground">Total Volume</span>
                <span className="font-semibold text-lg">
                  ${stats?.totalInvested?.toLocaleString() || "0"}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
