import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Copy } from "lucide-react";
import { StatCard } from "@/components/stat-card";
import { Tag } from "lucide-react";

export default function VIPCodesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold tracking-tight">VIP Codes</h1>
          <p className="text-muted-foreground">Manage VIP codes and rewards</p>
        </div>
        <Button data-testid="button-generate-vip-code">
          <Plus className="mr-2 h-4 w-4" />
          Generate Code
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard
          title="Total VIP Codes"
          value="456"
          icon={Tag}
          description="All time"
        />
        <StatCard
          title="Active Codes"
          value="234"
          icon={Tag}
          description="Available for use"
        />
        <StatCard
          title="Codes Used"
          value="222"
          icon={Tag}
          description="Total redeemed"
        />
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="font-heading">All VIP Codes</CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search codes..."
                className="pl-9 w-[300px]"
                data-testid="input-search-vip-codes"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Assigned To</TableHead>
                <TableHead>Discount Rate</TableHead>
                <TableHead>Max Usage</TableHead>
                <TableHead>Used Count</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <code className="font-mono font-semibold">VIP-ABC123</code>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell>John Doe</TableCell>
                <TableCell>
                  <span className="font-semibold">10%</span>
                </TableCell>
                <TableCell>5</TableCell>
                <TableCell>3</TableCell>
                <TableCell>
                  <Badge>Active</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" data-testid="button-view-vip-code">
                    View
                  </Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
