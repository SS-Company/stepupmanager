import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Users, Copy } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function InvestorNetwork() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-heading font-bold tracking-tight">My Network</h1>
        <p className="text-muted-foreground">Manage your referral network and track growth</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Your Referral Link</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="referral-link">Share this link to invite new investors</Label>
            <div className="flex gap-2">
              <Input
                id="referral-link"
                value="https://stepsup.com/ref/INV-001"
                readOnly
                data-testid="input-referral-link"
              />
              <Button variant="outline" data-testid="button-copy-referral-link">
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-3 pt-2">
            <div className="text-center p-4 rounded-md bg-muted/50">
              <div className="text-2xl font-bold font-heading">23</div>
              <p className="text-sm text-muted-foreground">Total Referrals</p>
            </div>
            <div className="text-center p-4 rounded-md bg-muted/50">
              <div className="text-2xl font-bold font-heading">10</div>
              <p className="text-sm text-muted-foreground">Left Leg</p>
            </div>
            <div className="text-center p-4 rounded-md bg-muted/50">
              <div className="text-2xl font-bold font-heading">13</div>
              <p className="text-sm text-muted-foreground">Right Leg</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Binary Tree Structure</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center gap-8 py-8">
            <div className="text-center">
              <Avatar className="h-16 w-16 mx-auto border-2 border-primary">
                <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
                  You
                </AvatarFallback>
              </Avatar>
              <p className="mt-2 font-medium">Your Position</p>
              <p className="text-sm text-muted-foreground">INV-001</p>
            </div>

            <div className="flex gap-16 md:gap-32">
              <div className="flex flex-col items-center gap-2">
                <div className="text-center">
                  <Avatar className="h-12 w-12 border-2">
                    <AvatarFallback>L1</AvatarFallback>
                  </Avatar>
                  <p className="mt-2 text-sm font-medium">Left Branch</p>
                  <p className="text-xs text-muted-foreground">10 members</p>
                </div>
              </div>

              <div className="flex flex-col items-center gap-2">
                <div className="text-center">
                  <Avatar className="h-12 w-12 border-2">
                    <AvatarFallback>R1</AvatarFallback>
                  </Avatar>
                  <p className="mt-2 text-sm font-medium">Right Branch</p>
                  <p className="text-xs text-muted-foreground">13 members</p>
                </div>
              </div>
            </div>

            <div className="text-center p-4 border-2 border-dashed rounded-md">
              <p className="text-sm text-muted-foreground">
                Full interactive tree visualization - will connect to real data
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Direct Referrals</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>R{i}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">Referral {i}</div>
                    <div className="text-sm text-muted-foreground">Joined Jan {i}, 2024</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">${(5000 * i).toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Total invested</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
