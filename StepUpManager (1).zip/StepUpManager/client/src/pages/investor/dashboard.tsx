import { StatCard } from "@/components/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, DollarSign, Users, Plus } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";

export default function InvestorDashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<any>({
    queryKey: ["/api/investor/stats"],
  });

  const { data: investments, isLoading: investmentsLoading } = useQuery<any[]>({
    queryKey: ["/api/investor/investments"],
  });

  const { data: commissions, isLoading: commissionsLoading } = useQuery<any[]>({
    queryKey: ["/api/investor/commissions"],
  });

  const recentCommissions = commissions?.slice(0, 3) || [];

  if (statsLoading || investmentsLoading || commissionsLoading) {
    return (
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-9 w-48 mb-2" />
            <Skeleton className="h-5 w-72" />
          </div>
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold tracking-tight">Welcome Back!</h1>
          <p className="text-muted-foreground">Here's your investment overview</p>
        </div>
        <Button data-testid="button-new-investment" asChild>
          <a href="/investments">
            <Plus className="mr-2 h-4 w-4" />
            New Investment
          </a>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Invested"
          value={`$${stats?.totalInvested?.toLocaleString() || "0"}`}
          icon={TrendingUp}
          description="Active capital"
        />
        <StatCard
          title="Expected Returns"
          value={`$${stats?.expectedReturns?.toLocaleString() || "0"}`}
          icon={DollarSign}
          description="projected earnings"
        />
        <StatCard
          title="Total Commissions"
          value={`$${stats?.totalCommissions?.toLocaleString() || "0"}`}
          icon={DollarSign}
          description="Lifetime earnings"
        />
        <StatCard
          title="Network Size"
          value={stats?.networkSize?.toString() || "0"}
          icon={Users}
          description="Your referrals"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-heading">Active Investments</CardTitle>
              <Button variant="outline" size="sm" data-testid="button-view-all-investments" asChild>
                <a href="/investments">View All</a>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {investments && investments.length > 0 ? (
              investments.slice(0, 2).map((investment) => {
                const progress = 50; // Calculate actual progress based on dates
                return (
                  <Card key={investment.id} className="border-2">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold font-heading">Investment #{investment.id}</h3>
                            <Badge>{investment.status}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            Started {new Date(investment.startDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold font-heading">
                            ${parseFloat(investment.amount).toLocaleString()}
                          </div>
                          <p className="text-sm text-muted-foreground">Principal</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Expected Return</span>
                          <span className="font-semibold text-green-600">
                            ${parseFloat(investment.expectedReturn).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">End Date</span>
                          <span className="font-semibold">
                            {new Date(investment.endDate).toLocaleDateString()}
                          </span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <div className="text-center py-12 border-2 border-dashed rounded-md">
                <p className="text-muted-foreground mb-4">No active investments yet</p>
                <Button asChild>
                  <a href="/investments">Create Your First Investment</a>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading">Referral Network</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-center p-6 border-2 border-dashed rounded-md">
              <div className="text-center">
                <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary mb-2">
                  <Users className="h-8 w-8" />
                </div>
                <p className="font-semibold">{stats?.networkSize || 0} Referrals</p>
                <p className="text-sm text-muted-foreground">Your network</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Left Leg</span>
                <span className="font-semibold">{stats?.leftLeg || 0}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Right Leg</span>
                <span className="font-semibold">{stats?.rightLeg || 0}</span>
              </div>
            </div>
            <Button variant="outline" className="w-full" data-testid="button-view-network" asChild>
              <a href="/network">
                <Users className="mr-2 h-4 w-4" />
                View Network
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Recent Commissions</CardTitle>
        </CardHeader>
        <CardContent>
          {recentCommissions.length > 0 ? (
            <div className="space-y-3">
              {recentCommissions.map((commission: any) => (
                <div
                  key={commission.id}
                  className="flex items-center justify-between p-3 rounded-md bg-muted/50"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <DollarSign className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="font-medium">{commission.commissionType} Commission</div>
                      <div className="text-sm text-muted-foreground">
                        {commission.description}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-green-600">
                      ${parseFloat(commission.amount).toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(commission.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No commissions earned yet
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
