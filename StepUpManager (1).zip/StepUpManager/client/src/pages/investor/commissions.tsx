import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/stat-card";
import { DollarSign } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function InvestorCommissions() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-heading font-bold tracking-tight">My Commissions</h1>
        <p className="text-muted-foreground">Track your earnings and commissions</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard
          title="Total Commissions"
          value="$8,500"
          icon={DollarSign}
          description="Lifetime earnings"
        />
        <StatCard
          title="This Month"
          value="$1,500"
          icon={DollarSign}
          trend={{ value: 20, isPositive: true }}
          description="vs last month"
        />
        <StatCard
          title="Pending Payouts"
          value="$500"
          icon={DollarSign}
          description="Awaiting approval"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-base">Binary Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-heading">$5,000</div>
            <p className="text-xs text-muted-foreground mt-1">From network growth</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-base">VIP Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-heading">$2,500</div>
            <p className="text-xs text-muted-foreground mt-1">From VIP bonuses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-base">Referral Commissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-heading">$1,000</div>
            <p className="text-xs text-muted-foreground mt-1">From direct referrals</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Commission History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>Jan 15, 2024</TableCell>
                <TableCell>
                  <Badge variant="outline">Binary</Badge>
                </TableCell>
                <TableCell>Level 2 Network Commission</TableCell>
                <TableCell className="font-semibold text-green-600">$500</TableCell>
                <TableCell>
                  <Badge>Paid</Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Jan 10, 2024</TableCell>
                <TableCell>
                  <Badge variant="outline">VIP</Badge>
                </TableCell>
                <TableCell>VIP Referral Bonus</TableCell>
                <TableCell className="font-semibold text-green-600">$750</TableCell>
                <TableCell>
                  <Badge>Paid</Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Jan 5, 2024</TableCell>
                <TableCell>
                  <Badge variant="outline">Referral</Badge>
                </TableCell>
                <TableCell>Direct Referral Commission</TableCell>
                <TableCell className="font-semibold text-green-600">$250</TableCell>
                <TableCell>
                  <Badge>Paid</Badge>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Jan 18, 2024</TableCell>
                <TableCell>
                  <Badge variant="outline">Binary</Badge>
                </TableCell>
                <TableCell>Level 3 Network Commission</TableCell>
                <TableCell className="font-semibold text-green-600">$300</TableCell>
                <TableCell>
                  <Badge variant="secondary">Pending</Badge>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
