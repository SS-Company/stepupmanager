import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Plus } from "lucide-react";

export default function InvestorInvestments() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold tracking-tight">My Investments</h1>
          <p className="text-muted-foreground">Track your investment portfolio</p>
        </div>
        <Button data-testid="button-new-investment">
          <Plus className="mr-2 h-4 w-4" />
          New Investment
        </Button>
      </div>

      <div className="grid gap-6">
        <Card className="border-2">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <CardTitle className="font-heading">Gold Plan</CardTitle>
                  <Badge>Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">Started Jan 1, 2024</p>
              </div>
              <Button variant="outline" size="sm" data-testid="button-view-investment-details">
                View Details
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Principal Amount</p>
                  <p className="text-2xl font-bold font-heading">$50,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Expected Return</p>
                  <p className="text-2xl font-bold font-heading text-green-600">$62,500</p>
                  <p className="text-sm text-muted-foreground">25% return rate</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Investment Progress</p>
                  <Progress value={50} className="h-2" />
                  <div className="flex justify-between mt-2 text-sm">
                    <span className="text-muted-foreground">45 days completed</span>
                    <span className="font-semibold">45 days remaining</span>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Maturity Date</p>
                  <p className="text-lg font-semibold">Mar 31, 2024</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <CardTitle className="font-heading">Silver Plan</CardTitle>
                  <Badge variant="outline">Maturing Soon</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">Started Dec 1, 2023</p>
              </div>
              <Button variant="outline" size="sm" data-testid="button-view-investment-details">
                View Details
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Principal Amount</p>
                  <p className="text-2xl font-bold font-heading">$20,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Expected Return</p>
                  <p className="text-2xl font-bold font-heading text-green-600">$24,000</p>
                  <p className="text-sm text-muted-foreground">20% return rate</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Investment Progress</p>
                  <Progress value={92} className="h-2" />
                  <div className="flex justify-between mt-2 text-sm">
                    <span className="text-muted-foreground">55 days completed</span>
                    <span className="font-semibold">5 days remaining</span>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Maturity Date</p>
                  <p className="text-lg font-semibold">Jan 30, 2024</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Available Investment Plans</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[
              { name: "Starter", min: "$1K", max: "$5K", rate: "15%", days: 30 },
              { name: "Silver", min: "$5K", max: "$20K", rate: "20%", days: 60 },
              { name: "Gold", min: "$20K", max: "$50K", rate: "25%", days: 90 },
              { name: "Platinum", min: "$50K", max: "$100K", rate: "30%", days: 120 },
              { name: "VIP", min: "$100K", max: "$500K", rate: "35%", days: 180 },
            ].map((plan) => (
              <Card key={plan.name} className="border-2 hover-elevate active-elevate-2">
                <CardHeader>
                  <CardTitle className="font-heading text-lg">{plan.name} Plan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Investment Range</span>
                    <span className="font-semibold">{plan.min} - {plan.max}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Return Rate</span>
                    <span className="font-semibold text-green-600">{plan.rate}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Duration</span>
                    <span className="font-semibold">{plan.days} days</span>
                  </div>
                  <Button className="w-full mt-2" variant="outline" data-testid={`button-invest-${plan.name.toLowerCase()}`}>
                    Invest Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
